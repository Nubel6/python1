numeros = [1,2,3,4,5,6,7,8,9,10,11,12,13,14]

for num in numeros:
    if num %2 == 0:
        print(num)


palabras =["hola","adíos", "buenas","tardes","carro","moto","bici","manzana"]

for pal in palabras:
    print((pal), " tiene ", len(pal), " caracteres")


agenda= {"Nombre" :"oscar",
        "edad" : "16",
        "Genero" : "masculino",
        "padres" : ["María", "Pedro"]
        }
for (x,y) in agenda.items():
    print(x,y)

oración = "Hola estoy en programación"
contador = 0 
letrab = "a"
for letra in oración:
    if letra == letrab:
        contador= contador +1
print("la letra", letrab, "en la oración aparece",contador)