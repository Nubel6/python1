import turtle
import random

ventana = turtle.Screen()
ventana.title("Carrera de tortugas  ")
ventana.bgcolor("lightgreen")
ventana.setup(720, 500)

linea_inicio = turtle.Turtle()
linea_inicio.penup()
linea_inicio.goto(-280, 170)
linea_inicio.pendown()
linea_inicio.goto(-280, -170)

linea_meta = turtle.Turtle()
linea_meta.penup()
linea_meta.goto(280, 170)
linea_meta.pendown()
linea_meta.goto(280, -170)

tortugas = []
colores = ["red", "purple", "blue", "green"]
for i in range(4):
    tortuga = turtle.Turtle()
    tortuga.shape("turtle")
    tortuga.color(colores[i])
    tortuga.penup()
    tortuga.goto(-320, 150 - i * 100)
    tortuga.pendown()
    tortugas.append(tortuga)

controles = turtle.Turtle()
controles.hideturtle()
controles.penup()
controles.goto(-270, -240)
controles.write("Controles:\nReiniciar >>> R\nIniciar >>> Espacio", font=("Arial", 16, "normal"))

def avanzar():
    ganador = None
    for tortuga in tortugas:
        if ganador is None:
            
            avance = random.randint(1, 20)
            tortuga.forward(avance)

           
            if tortuga.xcor() >= 300:
                ganador = tortuga
                color_original = ganador.color()[0]
                ganador.color("black")

                for i in range(5):
                    ganador.forward(5)
                    ganador.backward(5)

                ganador.color(color_original)
                controles.clear()
                controles.write("La tortuga " + color_original + " ha ganado", font=("Arial", 16, "normal"))
                ventana.onkey(reiniciar, "r")
        else:
            ":("
    if ganador is None:
        ventana.ontimer(avanzar, 100)

def reiniciar():
    global ganador
    ventana.clear()

    linea_inicio.penup()
    linea_inicio.goto(-280, 170)
    linea_inicio.pendown()
    linea_inicio.goto(-280, -170)

    linea_meta.penup()
    linea_meta.goto(280, 170)
    linea_meta.pendown()
    linea_meta.goto(280, -170)

    for i in range(4):
        tortuga = turtle.Turtle()
        tortuga.shape("turtle")
        tortuga.color(colores[i])
        tortuga.penup()
        tortuga.goto(-320, 150 - i * 100)
        tortuga.pendown()
        tortugas.append(tortuga)

    ganador = None
    ventana.onkey(reiniciar, "r")  
    ventana.onkeypress(avanzar, "space")
    ventana.listen()

    controles.clear()
    controles.goto(-270, -240)
    controles.write("Controles:\nReiniciar >>> R\nIniciar >>> Espacio", font=("Arial", 16, "normal"))  

ventana.onkey(reiniciar, "r")  
ventana.onkeypress(avanzar, "space")
ventana.listen()

turtle.mainloop()
