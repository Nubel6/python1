list=[]
nupares= []
nuimpares=[]

for i in range(10):
    numero= int(input("ingrese un número para la lista"))
    list.append(numero)

for x in list:
    if x%2 ==0:
        nupares.append(x)
    else:
        nuimpares.append(x)
print(list)
print("los númeroa pares son ",nupares)
print("la suma de los numero pares es de",sum(nupares))
print("el número máximo de la lista es",max(list))
print("eL NÚMERO pequeño de la lista es de",min(list))
print("los números impares son",nuimpares)
