class padre (object):
    def __init__(self,ojos,cejas):
        self.ojos=ojos
        self.cejas = cejas

class madre (object):
    def __init__(self,brazos,piernas):
        self.brazos=brazos
        self.piernas = piernas

class Hijo(padre, madre):
    def __init__(self, ojos, cejas,cara,brazos,piernas):
        padre.__init__(self,ojos,cejas)
        madre.__init__(self, brazos, piernas)
        self.cara = cara

penal = Hijo("cafes", "negras","larga", 2 , 2) 
print(penal.ojos,penal.cejas,penal.cara,penal.brazos,penal.piernas)

# palabras reservadas
#  class agregarelemento(list):
#      def append(self, alumno):
#          print("alumno agregado",(alumno))
#          super().append (alumno)

# lista1 = agregarelemento() lista1.append("Tania")
# print(lista1)