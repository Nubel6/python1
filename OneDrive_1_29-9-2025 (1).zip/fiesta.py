lista_de_invitados = ["120400898", "408987630", "305732087", "361798235"]
invitados = input("ingrese su cedula")
if invitados in lista_de_invitados :
    print("Bienvenido")
else : 
    print("no está en la lista")