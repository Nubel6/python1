import random
va= 100
vb= 100
na = str(input("ingrese el nombre del jugador A"))
nb = str(input("ingrese el nombre del jugador B"))
resp = str(input("Seleccione un jugador A o B"))

while True:
    a  = int(random.randint(1,100))
    b = int(random.randint(1,100))
    num = int(input("ingrese un numero del 1 al 2"))
    numCon = int(random.randint(1,2))

    if num == numCon:
        if resp == "a".lower():
            va = va - b
            vb= vb - a
            print(nb," ataca con un golpe de ", b, " y deja la vida de ", na, " en ", va)

            if va <= 0:
                print(nb, " GANA")
                break
            
            if vb <= 0:
                print(na, " GANA")
                break

            print(na," ataca con un golpe de ", a, " y deja la vida de ", nb, " en ", vb)
            if va <= 0:
                print(nb, " GANA")
                break
            
            if vb <= 0:
                print(na, " GANA")
                break

        else:
            vb= vb - a
            va = va - b
            print(na," ataca con un golpe de ", a, " y deja la vida de ", nb, " en ", vb)
            if va <= 0:
                print(nb, " GANA")
                break
            
            if vb <= 0:
                print(na, " GANA")
                break
            print(nb," ataca con un golpe de ", b, " y deja la vida de ", na, " en ", va)

            if va <= 0:
                print(nb, " GANA")
                break
            
            if vb <= 0:
                print(na, " GANA")
                break
    else:
        if resp == "a".lower():
            va = va - b
            vb= vb - a
            print(nb," ataca con un golpe de ", b, " y deja la vida de ", na, " en ", va)

            if va <= 0:
                print(nb, " GANA")
                break
            
            if vb <= 0:
                print(na, " GANA")
                break

            print(na," ataca con un golpe de ", a, " y deja la vida de ", nb, " en ", vb)
            if va <= 0:
                print(nb, " GANA")
                break
            
            if vb <= 0:
                print(na, " GANA")
                break

        else:
            vb= vb - a
            va = va - b
            print(na," ataca con un golpe de ", a, " y deja la vida de ", nb, " en ", vb)
            if va <= 0:
                print(nb, " GANA")
                break
            
            if vb <= 0:
                print(na, " GANA")
                break
            print(nb," ataca con un golpe de ", b, " y deja la vida de ", na, " en ", va)

            if va <= 0:
                print(nb, " GANA")
                break
            
            if vb <= 0:
                print(na, " GANA")
                break