"_" # Privado
"__"#protegido

# class usuario(object):
#     def __init__(self,nombre,clave):
#         self.nombre=nombre
#         self.__clave=clave

# usuario1= usuario("roberto ","qwerty")
# print(usuario1.nombre,usuario1._usuario__clave)

class Perro(object):
    def __init__(self,nombre,peso):
        self.__nombre= nombre
        self.__peso=peso

    @property
    def nombre(self):
        return self.__nombre
    #setter llena ro escribr nombres
    @nombre.setter
    def nombre (self,nuevo):
        print("modificando nombre")
        self.__nombre= nuevo
        print("El nombre se a modificado")
        print(self.__nombre)
#elimina el nombre
    @nombre.deleter#deleter para borrar
    def nombre(self):
        print("borrando nombre")
        del self.__nombre
    @property
    def peso(self):
        return self.__peso
    @peso.setter
    def peso (self,nuevopeso):
        print("modificando peso")
        self.__peso= nuevopeso
        print("El peso se a modificado")
        print(self.__peso)

    @peso.deleter
    def peso(self):
        print("borrando peso")


tomas = Perro("tom",27)
print(tomas.nombre)
tomas.nombre="Tomasito"
del tomas.nombre
print(tomas.peso)
tomas.peso = 28
del tomas.peso