
def sistema_inventario():
    inventario = {}  # Diccionario para almacenar productos
    
    while True:
        # Menú de opciones
        print("\n¿Qué te gustaría hacer?")
        print("1. Añadir un producto")
        print("2. Modificar el precio o cantidad de un producto")
        print("3. Eliminar un producto")
        print("4. Mostrar lista de productos")
        print("5. Mostrar el valor total del inventario")
        print("6. Salir")
        
        # Solicitar opción al usuario
        opcion = input("Selecciona una opción (1-6): ")
        
        if opcion == "1":
            # Añadir un producto
            nombre = input("Ingresa el nombre del producto: ")
            try:
                precio = float(input("Ingresa el precio del producto: "))
                cantidad = int(input("Ingresa la cantidad disponible: "))
                inventario[nombre] = {"precio": precio, "cantidad": cantidad}
                print(f"Producto '{nombre}' añadido con precio {precio} y cantidad {cantidad}.")
            except ValueError:
                print("Por favor, ingresa valores válidos para el precio y la cantidad.")
        
        elif opcion == "2":
            # Modificar el precio o cantidad de un producto
            nombre = input("Ingresa el nombre del producto a modificar: ")
            if nombre in inventario:
                print(f"Producto encontrado: {nombre} - Precio: {inventario[nombre]['precio']}, Cantidad: {inventario[nombre]['cantidad']}")
                try:
                    nuevo_precio = float(input("Ingresa el nuevo precio (deja vacío para no modificar): ") or inventario[nombre]['precio'])
                    nueva_cantidad = int(input("Ingresa la nueva cantidad (deja vacío para no modificar): ") or inventario[nombre]['cantidad'])
                    inventario[nombre]['precio'] = nuevo_precio
                    inventario[nombre]['cantidad'] = nueva_cantidad
                    print(f"Producto '{nombre}' actualizado con nuevo precio {nuevo_precio} y nueva cantidad {nueva_cantidad}.")
                except ValueError:
                    print("Por favor, ingresa valores válidos.")
            else:
                print(f"Producto '{nombre}' no encontrado.")
        
        elif opcion == "3":
            # Eliminar un producto
            nombre = input("Ingresa el nombre del producto a eliminar: ")
            if nombre in inventario:
                del inventario[nombre]
                print(f"Producto '{nombre}' eliminado del inventario.")
            else:
                print(f"Producto '{nombre}' no encontrado.")
        
        elif opcion == "4":
            # Mostrar la lista de productos
            if not inventario:
                print("El inventario está vacío.")
            else:
                print("Lista de productos en inventario:")
                for nombre, info in inventario.items():
                    print(f"{nombre}: Precio: {info['precio']}, Cantidad: {info['cantidad']}")
        
        elif opcion == "5":
            # Mostrar el valor total del inventario
            if not inventario:
                print("El inventario está vacío.")
            else:
                valor_total = sum(info['precio'] * info['cantidad'] for info in inventario.values())
                print(f"El valor total del inventario es: {valor_total:.2f}")
        
        elif opcion == "6":
            # Salir del programa
            print("¡Gracias por usar el sistema de inventario! ¡Hasta luego!")
            break
        
        else:
            print("Opción no válida, por favor intenta de nuevo.")

# Ejecutar el sistema de gestión de inventario
sistema_inventario()
