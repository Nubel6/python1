# class Humano():
    
#     def __init__(self , edad, nombre,ocupación):#constructor
#         self.edad=edad
#         self.nombre=nombre #atributos
#         self.ocupación = ocupación
#     def presentar(self):
#         presentacion= "Hola soy {}, mi edad es {} y mi ocupacion es {}"
#         print(presentacion.format(self.nombre, self.edad, self.ocupación)) #metodo

#     def contratar(self, puesto):
#         self.puesto= puesto
#         print ("{} ha sido contratado como {} ".format(self.nombre,self.puesto))
#         self.ocupación= puesto


# persona1 = Humano(16, "Jose", "Policía")
# persona2 = Humano(16,"marco", "Guarda bosques")
# persona3= Humano(16,"oscar", "programador")
# persona3.presentar()
# persona2.presentar()
# persona1.presentar()
# persona1.contratar("Portero")
# persona2.contratar("bombero")
# persona3.contratar("jefe de microsift")

class Estudiande(object):
    
    def __init__(self , edad, nombre):
        self.edad=edad
        self.nombre=nombre 

class colegio (object):
    def presentarcolegio(self):
        print("Estudio en el Colegio Tecnico de Puriscal")

class ciberseguridad(Estudiande,colegio):

    def presentar(self):
        print(f"Soy {self.nombre} tengo {self.edad} años y estudio ciberseguridad")

alejandro = ciberseguridad(16,"Alejandro")
alejandro.presentar()
alejandro.presentarcolegio()
class Dibujo(Estudiande ,colegio):

    def presentar(self):
        print(f"Soy {self.nombre} tengo {self.edad} años y estudio dibujo")

jose = Dibujo(16,"Jose")
jose.presentar()
jose.presentarcolegio()