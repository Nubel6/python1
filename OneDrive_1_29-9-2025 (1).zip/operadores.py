#aritmeticos
# + - / * % ** ptencias // devuelve las cantidades de enteros
#   Operando  operador  operando
print(12      +         14)


#Comparación
# == != diferentes > < >= <= 
if 1 == 2 :
    print ("Hola")

#aignación
# = += -= /= *= %= **=
contador = contador + 1
contador +=1

#Logicos
# and, solo si son iguales, or solo si las dos son falsas, not lo contrario
num = 1
num2 = 2
if num == 1 and num2 == 2:
    print("verdadero")
else: 
    print("falso")

#Especiales
# in, not in, is, not is