
palabras = []

for i in range(5):
    palabra1= input("ingrese una palabra")
    palabras.append(palabra1)

while True:
    num_carac= int(input("de cuantos caracteres es la palbra que desea eliminar"))
    for palabra in palabras:
        if len(palabra)<=num_carac:
            palabras.remove(palabra)
        elif len(palabra) == 0:
            break

    print("las palabras que no se eliminan son", palabras)

