
lista=[]
for i in range(5):
    num= int(input("ingrese un número"))
    lista.append(num)
pares=0
impares=0
for num in lista:
    if num %2==0:
        pares +=1
    else:
        impares
print("la cantidad de números pares son: ", pares)
print("la cantidad de números impares son: ", impares)
