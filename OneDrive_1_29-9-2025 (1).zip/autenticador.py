import random
codigo = random.randint(0,9999)