#instrucciones simples
b= 12
c = (2+2+8)
a= "hola"
print(a)

#instrucciones compuestas
if b==c:
    print(a)


a = "python" #instruccón simples
b = "aprender" #instruccón simples
c = "fácil" #instruccón simples
d = "Sintaxis" #instruccón simples
e = True #instruccón simples

if e == True:
    print(b + " " + a + " es " + c + " " + "si comprendo su " + d)
    print("se acaba de ejecutar una instrucción compuestas...")

print("pero ahora estamos ejecutando instrucciones simples...")
print("simplemente una tras otra....")