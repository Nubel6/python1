a = 2+2
if a == 4:
    print("A es igual a 4")
elif a == 5:
    print("A es igual a 5")
elif a ==6:
    print ("A es igual a 6")

else:
    print("No se cumple la condición")
libro = 25
cliente = 100
vuelto = cliente - libro
if cliente>= 25:
    print("si puede compar el libro")
    print(vuelto)
else:
    resp = input("tengo libros de menos valor, desea comprar alguno")
    if resp == "si":
        print("gracias por su compra")
    print("no le alcanza")
