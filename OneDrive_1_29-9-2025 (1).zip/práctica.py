#práctica1
num1 = input("ingrese un número")
num2 = input("ingrese un número")
if num1 > num2 :
    print("el primer numero es el mayor")
else:
    print("el segundo número es mayor")
#practica2
nu1 = int(input("ingrese un número"))
if nu1 >= 0:
    print("es positivo")
else:
    print("es negativo")
#practica3
num3 = int(input("dijite un número"))
if num3%2 == 0 :
    print("es par")
else:
    print("es impar")
#práctica4
num4 = int(input("dijite un número"))
num5 = int(input("dijite un número"))
num6 = int(input("dijite un número"))
if num4== num5 and num4==num6:
    print("todos los números son iguales",num4,num5,num6)

elif num4>num5 and num4>num6:
    if num4>num6:
        print(num4,num5,num6)
    else:
        print(num4,num6,num5)

elif num5>num4 and num5>num6:
    if num4>num6:
        print(num5,num4,num6)
    else:
        print(num5,num4,num6)

elif num6>num5 and num6>num4:
    if num4>num5:
        print(num6,num4,num5)
    else:
        print(num6,num5,num4)

