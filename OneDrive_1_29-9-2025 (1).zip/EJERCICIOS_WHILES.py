#import random
#c = random.randint(0,100) 
#resp = input(("adivine el número"))
#intentos = 0
#while True:
 #   resp = int(input("adivine el número"))
  #     print("adivino el número")
   #     intentos = intentos + 1
    #    print("usted tiene", intentos," intentos")
     #   break
    #elif resp > c :
     #   print("es más bajo")
      #  intentos = intentos + 1
    #elif resp < c :
     #   print("es más alto")
      #  intentos = intentos + 1
#while True:
 #   numero = int(input("inhgrese el número de la tabla que desea ver"))
  #  x = 1
   # while x <=10:
    #    print(x,"x", numero,"=",(x*numero))
     #   x+=1

    #respf = str(input("desea ver otra tabla Si/NO"))
    #if respf.lower() == "no":
     #   print("gracias por jugar")
      #  break

total = 0
contador = 0
while contador <=100:
    print(contador)
    total = total + contador
    contador +=2
print(total)