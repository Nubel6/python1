import tkinter as tk

def set_text():
    v.set("hola")

def get_text():
    print(v.get())

if __name__ == '__main__':
    rootWindow =tk.Tk()
    rootWindow.title("ventana Principal")

    v = tk.StringVar()
    campoTexto = tk.Entry(rootWindow, textvariable=v)
    campoTexto.pack(side=tk.LEFT)

    buttonset = tk.Button(rootWindow, text="hola", command=set_text)
    buttonset.pack(side=tk.LEFT)

    buttonget = tk.Button(rootWindow, text="Get", command=get_text)
    buttonget.pack(side=tk.LEFT)

    rootWindow.mainloop()

