#numeros pares o impares 
# num = int(input("ingrese un numero"))
# if num%2 == 0 :
#     print("el número si es par")
# else:
#     print("el número es impar")

# import random
# lista= random.randint(0,100)
# for i in range(lista):
#     print(i)

import random

def jugar():
    print("escoja una opción")
    print("1,piedra")
    print("2,tijeras")
    print("3,papel")

    usuario = int(input("cual opción escoges"))
    pc = random.randint(1,3)
    if usuario == pc:
        print("empate")
    elif usuario == 1:
        if pc == 2 :
            print("usuario gana")
        else:
            print("ganaste")
    elif usuario == 1 :
        if pc ==3:
            print("pc gana")
        else:
            print("ganaste")
    elif usuario == 2:
        if pc== 1 :
            print("pc gana")
    elif usuario == 2:
        if pc == 3:
            print("usuario gana")
    elif usuario == 3:
        if pc == 1:
            print("usuario gana")
    elif usuario == 3:
        if pc == 2 :
            print("pc gana")