#decoradores
def decorador (func):
    def nueva_funcion(self,mensaje):
        print("Perro dice:")
        func(self,mensaje)

    return nueva_funcion

class perro(object):
    def __init__ (self, nombre):
        self.nombre=nombre

    @decorador
    def saluda(self,mensaje):
        self.mensaje=mensaje
        print(mensaje)
        print("guau")
firu = perro("Firu")
firu.saluda("hola yo programo en canton")


# @decorador
# def saludar():
#     print("GUAU!")

# @decorador
# def despedida():
#     print("Chau")

# def movercola():
#     print("El perro mueve la cola")

# saludar()
# despedida()
# movercola()