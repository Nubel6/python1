#comprobar si un número es primo o no primo 
numprimo= int(input("ingrese un número"))
if numprimo %2 :
    print("es primo")
else:
    print("no primo")