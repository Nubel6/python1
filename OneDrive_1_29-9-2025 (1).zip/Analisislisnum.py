contar_ceros = 0
lista1= input("ingrese un número separado por comas")
numeros = [int(num)for num in lista1.split(",")]
positivos = []
negativos=[]
for numero in numeros:
    if numero>0:
        positivos.append(numero)
    elif numero<0:
        negativos.append(numero)
    else:
        contar_ceros +=1
print("Numero positivos:",positivos)
print("numero negativos:",negativos)
print("cantidad de 0s:",contar_ceros)


