x = list(range(5))
x = list(range(2,20,2))
x.insert(9,20)
print(x)

info = {"Nombre" :"oscar",
        "edad" : "16",
        "Genero" : "masculino",
        "padres" : ["María", "Pedro"]
        }
print(info["Nombre"])
print(info["padres"] [0:2])
#info["Genero"] = info.pop("sexo") # cambiar el nombre de la clave
del(info["edad"]) #eliminar una clave
info["País"] = "Costa Rica" #agrega una clave
info["Nombre"] = "Carlos" #cambia el valorsi la clave ya está
nom = info.get("Nombre", "No tiene nombre")
print(nom)
claves = info.keys()
valores = info.values()
print(claves)
print(valores)