palabra = input("ingrese uan palabra")
for x in range(10):
    print(palabra) 

user = int(input("ingrese su edad"))
for x in range(user):
    print(x +1)

años = int(input("ingrese el año en el que nació"))
for x in range((2025-años)):
    print("en el año", (años+x) , "usted tenáia",x,"años")

#pedir un número al usuario

use = int(input("ingrese un numero"))
for x in range(use,-1,-1):
    print (x)