class animalmamifero(object):
    def __init__(self, pelo,boca,ojos,extremidades):
        self.pelo=pelo
        self.boca=boca
        self.ojos=ojos
        self.extremidades=extremidades


class animasocial(animalmamifero):
    def __init__(self, pelo, boca, ojos, extremidades, cariñoso,juguetón):
        super().__init__(pelo, boca, ojos, extremidades)
        self.cariñoso=cariñoso
        self.juguetón=juguetón


gato= animasocial("negro","pequeña","verdes",4,"cariños","juguetón")
print("el pelage del gato es",gato.pelo,"la boca del gato es ",gato.boca, " los ojos del gato son de color ",gato.ojos,"el gato tiene ",gato.extremidades ,"patas","es",gato.juguetón,"y",gato.cariñoso)