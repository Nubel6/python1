calificaciones= []
aprobados=[]
reprobados=[]
while True:
    pregunta = input("Quiere ingresar la calificación de otro estudiante si/no")
    if pregunta == "si":
        usuario= int(input("ingrese la calificación del estudiante"))
    else:
        break
    calificaciones.append(usuario)
suma=0
for i in calificaciones:
    suma += i
    promedio= suma  /len(calificaciones)
    if i >= 60:
        aprobados.append(i)
    elif i <=59:
        reprobados.append(i)
print(calificaciones)
print("lo estudiantes que reprobaron son",reprobados)
print("los estudiantes aprobados son", aprobados)
print(promedio)