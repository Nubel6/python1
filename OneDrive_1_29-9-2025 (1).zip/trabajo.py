import autenticador
codigo = autenticador.codigo #se puede importar a otro ejercicio
print(codigo)

usuario = "Pepitoloco"
user = input("ingrese el nombre de ususario")
Contraseña = "Pepito1234"
password = input("ingrese una contraseña")
if Contraseña == password and usuario == user:
    codigousuario = int(input("ingrese su codigo de autenticación"))#int convierte de número a caracter
    if codigo == codigousuario:
        print("bienvenido al imalla elao")
    else:
        print("Codigo incorrecto")
else:
    print("contraseña es incorrecta")