#Variable de clase
class perros(object):
    collar = True
    def __init__(self,salud,hambre):
        self.salud=salud
        self.hambre=hambre

print(perros.collar)

#Variable de instancia
Salchicha= perros(100,50)
print(Salchicha.hambre)

#metodos de clase
class animal(object):
    @classmethod
    def correr (self, km):
        print("El animal corre %s kilometros" %km)
animal.correr(12)

#metodod de instancia
class Ave (object):
    def __init__(self):
        pass
    
    def hablar (self,color):
        print("soy una jodida ave de color %s" %color)
    #metodos estaticos
    @staticmethod
    def volar(tiene_alas,kms):
        if tiene_alas == True:
            print("El ave se fue volando %i kilometros"%kms)
        else:
            ("esta ave no puede volar")

loro = Ave()
loro.hablar("Morado")

Ave.volar(True,5)


