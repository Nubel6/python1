
usuario = input("3 para piedra /1 para papel /2 para tijera")
import random
compu = random.randint(1,3)
if compu == usuario :
    print("empate")
elif compu == 1 and usuario == 2:
    print("gana el usuario") 
elif compu == 1 and usuario == 3:
    ("gana computadora")
elif compu == 2 and usuario == 1:
    print ("Gana compu")
elif compu == 2 and usuario == 3:
    print("Gana el usuario")
elif compu == 3 and usuario == 1:
    print("Gana usuario")
elif compu == 3 and usuario == 2:
    print("Gana computadora")
else:
    print("el usuario no escogió una opción Valida")
