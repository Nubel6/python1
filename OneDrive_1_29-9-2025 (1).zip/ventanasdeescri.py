from guizero import *
root = App(title="aplicacion", bg="darkblue", width=300,height=200)
boton = PushButton(root,text="salir",align="bottom",padx=25,pady= 2,command=quit)
boton.bg=("red")
root.display()