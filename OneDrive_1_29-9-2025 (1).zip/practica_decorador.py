def decorador (func):
    def nueva_funcion(self,mensaje):
        print("Yo trabajo en:")
        func(self,mensaje)

    return nueva_funcion

class profesion(object):
    def __init__(self,profesion):
        self.profesion=profesion
    @decorador
    def saludo(self, mensaje):
        self.mensaje=mensaje
        print(mensaje)
        

trabajo = profesion("medico")
trabajo.saludo("hola yo trabajo de ")