#while(condición):
#    cuerpo de la repetició
#i= 0 
#while(i <=9):
#   i +=1
#  print(i)
#while True:
#    resp = input("Saprissa es el mejor equipo si/no")
#    if resp == "si":
#        print("buena respuesta")
#        break
#    else:
#        print("piense mejor su respuesta")
def sumar():
    x = a + b
    print("resultado =",x)
def resta ():
    x = a - b
    print("resultado = ",x)

def multi ():
    x = a * b
    print("resultado = ",x)

def division ():
    x = a / b
    print("resultado = ",x)
while True:
    try:
        a = int(input("ingrese u número"))
        b = int(input("ingrese u número"))

        print("que calculo desea realizar")
        op = str(input("""
        1 - sumar
        2 - restar
        3 - multi
        4 - division
        \n"""))

        if op == "1":
            sumar()
            break
        elif op == "2":
            resta()
            break
        elif op =="3":
            multi()
            break
        elif op == "4":
            division()
        else:
            print("has ingresado un numero de opción erroneo")

    except ZeroDivisionError:
        print("nuestra calculadora no permite dividir por 0")

    except:
        print("error")
        op =  "?"
    
    finally:
        print("gracias po usar nuestra calculadora")